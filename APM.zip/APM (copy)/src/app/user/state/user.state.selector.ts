import { createFeatureSelector, createSelector } from '@ngrx/store';
import { UserState } from './user.state';

const getUserFeatureState = createFeatureSelector<UserState>('user');

export const getMaskUserName = createSelector(getUserFeatureState, state => {

    return state.maskUserName;
});

export const getCurrentUser = createSelector(getUserFeatureState, state => {

    return state.currentUser;
});