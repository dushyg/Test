import { UserState } from './user.state';
import * as userActions from './user.action';

const initialUserState : UserState = {

    currentUser : null,
    maskUserName : true
};

export function userReducer(state : UserState = initialUserState, action : userActions.UserActions) : UserState {

    switch (action.type) {
        case userActions.UserActionTypes.ToggleMaskUserName:
            console.log('current state : '+JSON.stringify(state));
            console.log('payload : '+action.payload);
            return {

                ...state,
                maskUserName : action.payload
            };
    
        default:
            return state;
    }
}