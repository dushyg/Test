import { UserState } from './user/state/user.state';

export interface State {

    showWelcomePage : boolean,
    userState : UserState
}