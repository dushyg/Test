import { Component, OnInit, ChangeDetectionStrategy } from '@angular/core';
import { Store, select } from '@ngrx/store';
import { Observable } from 'rxjs';

import { Product } from '../../product';
import { ProductService } from '../../product.service';

import * as fromProduct from '../../state/product.state';
import { getShowProductCode, getCurrentProduct, getProductList, getProductListError } from '../../state/product.state.selectors';
import * as productActions from '../../state/product.action';

@Component({
    templateUrl: './product-shell.component.html',
    changeDetection : ChangeDetectionStrategy.OnPush
})
export class ProductShellComponent implements OnInit {

    constructor(private productService: ProductService, private store : Store<fromProduct.State>) { }
    
    // Used to highlight the selected product in the list
    selectedProduct$: Observable<Product | null>;    
    products$: Observable<Product[]>;
    error$: Observable<string>;
    showProductCode$ : Observable<boolean>;
    
  ngOnInit() {
    
        this.showProductCode$ = this.store.pipe(select(getShowProductCode));              

        this.selectedProduct$ = this.store.pipe(select(getCurrentProduct));

        this.products$ = this.store.pipe(select(getProductList));

        this.error$ = this.store.pipe(select(getProductListError));
        
        this.store.dispatch(new productActions.LoadAllProducts());

   }

  checkChanged(value: boolean): void {

    let action  = new productActions.ToggleProductCode(value);
    //console.log(action);
    //console.log(JSON.stringify(action));
    this.store.dispatch(action);
  }

  newProduct(): void {
    //this.productService.changeSelectedProduct(this.productService.newProduct());
    this.store.dispatch(new productActions.InitializeCurrentProduct());
  }

  productSelected(product: Product): void {
    //this.productService.changeSelectedProduct(product);
    this.store.dispatch(new productActions.SetCurrentProduct(product));

  }

  
}
