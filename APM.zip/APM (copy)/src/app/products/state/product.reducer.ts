import { ProductState } from './product.state';
import { ProductActions, ProductActionTypes } from './product.action';
import { Product } from '../product';

export const initialProductState : ProductState = {

    showProductCode : true,
    currentProductId : null,
    productList : [],
    error : ''
};

export function productReducer(state : ProductState = initialProductState , action : ProductActions ) : ProductState {
    console.log('Existing state : '+JSON.stringify(state));
    console.log('Action : '+JSON.stringify(action));

    switch (action.type) {
        case ProductActionTypes.ToggleProductCode :
            
            return {
                ...state,
                showProductCode : action.payload
            };
        case ProductActionTypes.SetCurrentProduct :
            
            return {
                ...state,
                currentProductId : action.payload.id
            };
        case ProductActionTypes.ClearCurrentProduct :
            
            return {
                ...state,
                currentProductId : null
            };
        case ProductActionTypes.InitializeCurrentProduct :
            
            return {
                ...state,
                currentProductId : 0
            };
        case ProductActionTypes.LoadAllProductsSuccess :
            return {
                ...state,
                productList : action.payload,
                error : ''
            };
        case ProductActionTypes.LoadAllProductsFailed :
            return {
                ...state,
                productList : null,
                error : action.payload
            };        
        case ProductActionTypes.UpdateProductSuccess : 
            const updatedProducts = state.productList.map( product => {

                return product.id === action.payload.id ? action.payload : product;
            }); 
            
            return {
                ...state,
                currentProductId : action.payload.id,
                error : '',
                productList : updatedProducts
            };
        case ProductActionTypes.UpdateProductFailed :
            return {
                ...state,
                error : action.payload
            };    
        case ProductActionTypes.AddNewProductSuccess :
            let newProductList : Product[] = state.productList.slice(0);
            newProductList.unshift(action.payload);
            return {
                ...state,
                currentProductId : action.payload.id,
                productList : newProductList,
                error : ''
            };
        case ProductActionTypes.AddNewProductFailed :
            return {
                ...state,
                error : action.payload
            };
        case ProductActionTypes.DeleteProductSuccess :
            let postDeleteProductList = state.productList.filter( product => {
                return product.id !== action.payload;
            });
            return {
                ...state,
                currentProductId : null,
                productList : postDeleteProductList,
                error : ''
            };
        case ProductActionTypes.DeleteProductFailed : 
            return {
                ...state,
                error : action.payload
            };
        default:
            return state;
    }

}