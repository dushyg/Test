import { Actions, Effect, ofType } from '@ngrx/effects';
import { Injectable } from '@angular/core';
import { ProductService } from '../product.service';
import * as productActions from './product.action';
import { mergeMap, map, catchError } from 'rxjs/operators';
import { Product } from '../product';
import { of } from 'rxjs';

@Injectable()
export class ProductEffects {

    constructor(private actions$: Actions,
        private productService: ProductService) {

    }

    @Effect()
    loadProducts$ = this.actions$.pipe(
        ofType(productActions.ProductActionTypes.LoadAllProducts),
        mergeMap((action: productActions.LoadAllProducts) => {
            return this.productService.getProducts().pipe(
                map((products: Product[]) => {
                    return new productActions.LoadAllProductsSuccess(products);
                }),
                catchError( (error) => {
                    return of(new productActions.LoadAllProductsFailed(error));
                }));
        })
    );

    @Effect()
    updateProduct$ = this.actions$.pipe(
        ofType(productActions.ProductActionTypes.UpdateProductRequest),
        mergeMap( (action : productActions.UpdateProductRequest) => {

            return this.productService.updateProduct(action.payload)
                    .pipe(
                        map( (updatedProduct : Product) => {
                            return new productActions.UpdateProductSuccess(updatedProduct);
                        }),
                        catchError( error => {
                            return of(new productActions.UpdateProductFailed(error));
                        })
                    );
                })
        );    

    @Effect()
    addNewProduct$ = this.actions$.pipe(
        ofType(productActions.ProductActionTypes.AddNewProductRequest),
        mergeMap( (action : productActions.AddNewProductRequest)=> {
            return this.productService.createProduct(action.payload).pipe(
                map( addedProduct => {

                    return new productActions.AddNewProductSuccess(addedProduct);
                }),
                catchError( (error) => {
                    return of(new productActions.AddNewProductFailed(error));
                })
            );
        })
    );

    @Effect()
    deleteProduct$ = this.actions$.pipe(
        ofType(productActions.ProductActionTypes.DeleteProductRequest),
        mergeMap( (action : productActions.DeleteProductRequest) => {
            return this.productService.deleteProduct(action.payload).pipe(
                map( () => {
                    
                    return new productActions.DeleteProductSuccess(action.payload);
                }),
                catchError( error => {

                    return of(new productActions.DeleteProductFailed(error)); 
                })
            );
        })
    );    
















}
