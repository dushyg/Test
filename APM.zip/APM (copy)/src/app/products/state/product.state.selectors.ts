import { createFeatureSelector , createSelector } from '@ngrx/store';
import { ProductState } from './product.state';
import { Product } from '../product';

const getProductFeatureState = createFeatureSelector<ProductState>('products');

export const getShowProductCode = createSelector(getProductFeatureState, state => {

    return state.showProductCode;
});


export const getCurrentProductId = createSelector(getProductFeatureState, state => {
    return state.currentProductId;
});

export const getCurrentProduct = createSelector(
    getProductFeatureState, getCurrentProductId, 
    (state, productId) => {

        if(productId === 0) {
            let product : Product = {
                id : 0,
                description : '',
                productCode : 'new',
                productName : '',
                starRating : 0
            } ;
            return product;
        }
        else {
            return productId ? state.productList.find( p => p.id === productId) : null;

        }
    
});

export const getProductList = createSelector(getProductFeatureState, state => {

    return state.productList;
})

export const getProductListError  =  createSelector(getProductFeatureState, state => {
    return state.error;
})