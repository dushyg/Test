import * as fromApp from '../../app.state';
import { Product } from '../product';

export interface ProductState {

    showProductCode : boolean,
    currentProductId : number | null,
    productList : Product[],
    error : string
    
}

export interface State extends fromApp.State {

    products : ProductState
}