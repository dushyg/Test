import { Action } from '@ngrx/store';
import { Product } from '../product';

export enum ProductActionTypes {

    ToggleProductCode = "[Product] Toggle Product Code",
    SetCurrentProduct = "[Product] Set Current Product",
    ClearCurrentProduct = "[Product] Clear Current Product",
    InitializeCurrentProduct = "[Product] Initialize Current Product",

    LoadAllProducts = "[Product] Load All Products Requested",
    LoadAllProductsSuccess = "[Product] Load All Products Succeeded",
    LoadAllProductsFailed = "[Product] Load All Products Failed",

    UpdateProductRequest = "[Product] Update Product Request",
    UpdateProductSuccess = "[Product] Update Product Success",
    UpdateProductFailed = "[Product] Update Product Failed",

    AddNewProductRequest = "[Product] Add New Product Request",
    AddNewProductSuccess = "[Product] Add New Product Success",
    AddNewProductFailed = "[Product] Add New Product Failed",


    DeleteProductRequest = "[Product] Delete Product Request",
    DeleteProductSuccess = "[Product] Delete Product Success",
    DeleteProductFailed  = "[Product] Delete Product Failed"
}

export class AddNewProductRequest implements Action {

    readonly type = ProductActionTypes.AddNewProductRequest;
    constructor(public payload : Product) {

    }
}
export class AddNewProductSuccess implements Action {

    readonly type = ProductActionTypes.AddNewProductSuccess;
    constructor(public payload : Product) {
        
    }
}

export class AddNewProductFailed implements Action {

    readonly type = ProductActionTypes.AddNewProductFailed;
    constructor(public payload : string) {

    }
}

export class DeleteProductRequest implements Action {
    readonly type = ProductActionTypes.DeleteProductRequest;
    constructor(public payload : number) {

    }
}

export class DeleteProductSuccess implements Action {
    readonly type = ProductActionTypes.DeleteProductSuccess;
    constructor(public payload : number) {

    }
}

export class DeleteProductFailed implements Action {
    readonly type = ProductActionTypes.DeleteProductFailed;
    constructor(public payload : string) {

    }
}

export class UpdateProductRequest implements Action {

    readonly type = ProductActionTypes.UpdateProductRequest;
    constructor(public payload : Product){

    }
}

export class UpdateProductSuccess implements Action {

    readonly type = ProductActionTypes.UpdateProductSuccess;    
    constructor(public payload : Product){

    }
}

export class UpdateProductFailed implements Action {

    readonly type = ProductActionTypes.UpdateProductFailed;
    constructor(public payload : string) {

    }
}

export class LoadAllProducts implements Action {

    readonly type = ProductActionTypes.LoadAllProducts;    
}

export class LoadAllProductsSuccess implements Action {

    readonly type = ProductActionTypes.LoadAllProductsSuccess;
    constructor(public payload : Product[]) {

    }
}

export class LoadAllProductsFailed implements Action {

    readonly type = ProductActionTypes.LoadAllProductsFailed;
    constructor(public payload : string) {

    }
}
export class ToggleProductCode implements Action {

    public readonly type = ProductActionTypes.ToggleProductCode;

    constructor(public payload : boolean) {

    }
}

export class SetCurrentProduct implements Action {

    public readonly type = ProductActionTypes.SetCurrentProduct;

    constructor(public payload : Product) {

    }
}

export class ClearCurrentProduct implements Action {

    public readonly type = ProductActionTypes.ClearCurrentProduct;
}

export class InitializeCurrentProduct implements Action {

    public readonly type = ProductActionTypes.InitializeCurrentProduct;    
}

export type ProductActions = ToggleProductCode
                            | ClearCurrentProduct
                            | SetCurrentProduct
                            | InitializeCurrentProduct
                            | LoadAllProducts
                            | LoadAllProductsSuccess
                            | LoadAllProductsFailed
                            | UpdateProductRequest 
                            | UpdateProductSuccess
                            | UpdateProductFailed
                            | AddNewProductRequest
                            | AddNewProductFailed
                            | AddNewProductSuccess
                            | DeleteProductRequest
                            | DeleteProductSuccess
                            | DeleteProductFailed; 