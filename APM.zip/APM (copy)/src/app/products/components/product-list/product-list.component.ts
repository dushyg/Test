import { Component, OnInit, OnDestroy, Input, Output, EventEmitter } from '@angular/core';
import { Product } from '../../product';

@Component({
  selector: 'pm-product-list',
  templateUrl: './product-list.component.html',
  styleUrls: ['./product-list.component.css']
})
export class ProductListComponent {
  pageTitle = 'Products';
    
  @Input('error') errorMessage: string;
  @Input('showProductCode') displayCode: boolean;
  @Input('productList') products: Product[];

  // Used to highlight the selected product in the list
  @Input('currentProduct') selectedProduct: Product | null;
  
  @Output() newProductAdded  = new EventEmitter<void>();
  @Output() showProductCodeToggle = new EventEmitter<boolean>();
  @Output() onProductSelected = new EventEmitter<Product>();  

  checkChanged(value: boolean): void {
      this.showProductCodeToggle.emit(value);
  }

  newProduct(): void {
      this.newProductAdded.emit();
  }

  productSelected(product: Product): void {
      this.onProductSelected.emit(product);
  }

}
